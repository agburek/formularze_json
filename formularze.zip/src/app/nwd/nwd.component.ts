import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-nwd',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './nwd.component.html',
  styleUrl: './nwd.component.css'
})
export class NwdComponent {

  a:number = 0;
  b:number = 0;
  nwd:number = 0;
  komunikat:string = "";
  
obliczNWD() {

let ak = this.a;
let bk = this.b;

  while(ak!=bk){
    if (ak>bk)
      ak = ak-bk
    else
      bk = bk-ak

      
      this.nwd = ak
      this.komunikat = `NWD(${this.a},${this.b})=${this.nwd}`
    
  }
}
}
