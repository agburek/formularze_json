import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FilmyComponent } from "./filmy/filmy.component";
import { NwdComponent } from "./nwd/nwd.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FilmyComponent, NwdComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'formularze';
}
